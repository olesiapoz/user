package main

import (
//	"fmt"
	"muser"
)

// Main forwading to Hello
func Muser(args map[string]interface{}) map[string]interface{} {

	return muser.Muser(args)
}
